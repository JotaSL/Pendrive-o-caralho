﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Projeto18270_18260
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            try
            {
                MySqlConnection con = new MySqlConnection("server=143.106.241.3;port=3306;User ID=cl18252;database=cl18252;password=cl*18082003");
                con.Open();
                MessageBox.Show("Conectado");
                con.Close();
            }
            catch
            {
                MessageBox.Show("Falha na Conexão");
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                MySqlConnection con = new MySqlConnection("server=143.106.241.3;port=3306;User ID=cl18252;database=cl18252;password=cl*18082003");
                con.Open();
                MySqlCommand insere = new MySqlCommand("insert into Alunos (idAlunos, nomeAlunos, turmaAlunos, emailAlunos) values ("+textBox1.Text+",'"+textBox2.Text+"','"+comboBox1.SelectedItem.ToString()+ "','" + textBox3.Text + "')", con);
                insere.ExecuteNonQuery();
                MessageBox.Show("Gravação realizada com sucesso");
                con.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show("Falha na gravação");
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
