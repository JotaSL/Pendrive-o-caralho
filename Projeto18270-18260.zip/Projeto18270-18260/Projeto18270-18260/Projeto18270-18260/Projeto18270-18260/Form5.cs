﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto18270_18260
{
    public partial class Form5 : Form
    {
        MySqlConnection con;
        int idPalestra;
        string horaPalestra = "", diaPalestra = "";
        private MySqlDataAdapter mySqlDataAdapter;

        public Form5()
        {
            InitializeComponent();
            try
            {
                con = new MySqlConnection("server=143.106.241.3;port=3306;User ID=cl18252;database=cl18252;password=cl*18082003");
                con.Open();
                MessageBox.Show("Conectado");
            }
            catch
            {
                MessageBox.Show("Falha na Conexão");
            }
            finally
            {
                con.Close();
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                MySqlCommand busca_palestra = new MySqlCommand("Select tituloPalestra, idPalestras, diaPalestra, horaPalestra from Palestras where tituloPalestra='" + comboBox1.SelectedItem.ToString() + "'", con);
                MySqlDataReader resultado = busca_palestra.ExecuteReader();
                if (resultado.Read())
                {
                    idPalestra = Convert.ToInt32(resultado["idPalestras"].ToString());
                    diaPalestra = resultado["diaPalestra"].ToString();
                    horaPalestra = resultado["horaPalestra"].ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                con.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                mySqlDataAdapter = new MySqlDataAdapter("SELECT idAlunos, nomeAlunos FROM Alunos al,Presenca pr, Palestras pa WHERE al.idAlunos = pr.RA AND pr.idPalestras = pa.idPalestras AND al.turmaAlunos ='" + comboBox2.SelectedItem.ToString() + "'AND pa.idPalestras = " +idPalestra+ "order by nomeAlunos", con);

                DataSet DS = new DataSet();
                mySqlDataAdapter.Fill(DS);
                dataGridView1.DataSource = DS.Tables[0];
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                con.Close();
            }
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                MySqlCommand busca_palestra = new MySqlCommand("Select tituloPalestra from Palestras", con);
                MySqlDataReader resultado = busca_palestra.ExecuteReader();
                while (resultado.Read())
                {
                    comboBox1.Items.Add(resultado["tituloPalestra"].ToString());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                con.Close();
            }
        }
    }
}
