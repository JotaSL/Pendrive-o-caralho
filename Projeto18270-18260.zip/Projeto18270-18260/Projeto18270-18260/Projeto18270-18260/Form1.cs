﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto18270_18260
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            //clRA
            //cl* DataNascimento
            //143.106.241.3              3306
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void cadastrarAlunosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Form2>().Count() == 0)
            {
                Form filha2 = new Form2();
                filha2.MdiParent = this;
                filha2.Show();
            }
        }

        private void arquivoToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void palestraToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Form3>().Count() == 0)
            {
                Form filho3 = new Form3();
                filho3.MdiParent = this;
                filho3.Show();
            }
        }

        private void frequênciaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Form4>().Count() == 0)
            {
                Form filho4 = new Form4();
                filho4.MdiParent = this;
                filho4.Show();
            }
        }

        private void relatóriosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Form4>().Count() == 0)
            {
                Form filho5 = new Form5();
                filho5.MdiParent = this;
                filho5.Show();
            }
        }
    }
}
