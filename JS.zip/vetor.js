	var vetor = new Array(5);

	for (var i = 0; i < vetor.lenght; i++)
	{
		vetor[i] = prompt("Digite um valor:");
	}

		
		
		function addPrimeiroPos(){
			var valor document.getElementById("txtValor").value;

			if (valor.trim() == "") {
				alert("Informe um valor!");
			}else{
				vetor.unshift(valor);
				atualizaTela();
			}
		}

		function atualizaTela(){

			var dadosVetor = "<b>Dados do Vetor:</b><br><br>";
	
			for (var i = 0; i < vetor.length; i++) {
		  dadosVetor = dadosVetor + vetor[i] + "<br>";
		}

		var divHTML = document.getElementById("exibeVetor");
		divHTML.innerHTML = dadosVetor;
	
		}